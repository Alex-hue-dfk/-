package КР

fun main() {
    val dialogProgress = `Контрольная работа DialogProgress`()
    dialogProgress.start()
}