package КР

class `Контрольная работа DialogGraph` {
    private val nodes = mutableMapOf<`Контрольная работа`, `Контрольная работа DialogNode`>()

    init {
        // Создаем все узлы диалога
        val start = `Контрольная работа DialogNode`(
            `Контрольная работа`.START,
            "Привет, подходи сюда."
        )
        val talking = `Контрольная работа DialogNode`(
            `Контрольная работа`.TALKING,
            "Я смотрю, ты тут впервые. Могу научить тебя сражаться. Хочешь?"
        )
        val accepted = `Контрольная работа DialogNode`(
            `Контрольная работа`.ACCEPTED,
            "Отлично, убей вон того манекена."
        )
        val decline = `Контрольная работа DialogNode`(
            `Контрольная работа`.DECLINE,
            "Тогда удачной дороги, путник!"
        )
        val dummyKilled = `Контрольная работа DialogNode`(
            `Контрольная работа`.DUMMY_KILLED,
            "Ты убил манекена? Подходи сюда!"
        )
        val completed = `Контрольная работа DialogNode`(
            `Контрольная работа`.COMPLETED,
            "Отлично! Ты доказал, что умеешь сражаться."
        )


        start.addChoice("1. Поговорить", `Контрольная работа`.TALKING)


        talking.addChoice("1. Принять задание", `Контрольная работа`.ACCEPTED)
        talking.addChoice("2. Отказаться", `Контрольная работа`.DECLINE)


        accepted.addChoice("1. Завершить", `Контрольная работа`.COMPLETED)


        decline.addChoice("1. Завершить", `Контрольная работа`.COMPLETED)


        completed.addChoice("1. Начать заново", `Контрольная работа`.START)

        // Добавляем все узлы в граф
        nodes[start.state] = start
        nodes[talking.state] = talking
        nodes[accepted.state] = accepted
        nodes[decline.state] = decline
        nodes[dummyKilled.state] = dummyKilled
        nodes[completed.state] = completed
    }

    fun getNode(state: `Контрольная работа`): `Контрольная работа DialogNode`? {
        return nodes[state]
    }

}