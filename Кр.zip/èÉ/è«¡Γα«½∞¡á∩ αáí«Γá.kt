package КР

enum class `Контрольная работа`{
    START,
    TALKING,
    ACCEPTED,
    DECLINE,
    DUMMY_KILLED,
    COMPLETED
}