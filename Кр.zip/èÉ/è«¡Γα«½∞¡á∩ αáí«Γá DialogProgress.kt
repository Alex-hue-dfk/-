package КР

class `Контрольная работа DialogProgress` {
    private val graph = `Контрольная работа DialogGraph`()
    private var currentState = `Контрольная работа`.START

    fun start() {
        println("=== ДИАЛОГОВАЯ СИСТЕМА ===")

        while (true) {
            val currentNode = graph.getNode(currentState)
            if (currentNode == null) {
                println("Ошибка: состояние $currentState не найдено!")
                break
            }

            // Показываем текущий диалог
            currentNode.print()

            // Если нет вариантов выбора - завершаем
            if (currentNode.getChoicesCount() == 0) {
                println("Диалог завершен!")
                break
            }

            // Обрабатываем ввод пользователя
            print("> ")
            val input = readLine()?.trim() ?: continue

            if (input == "exit") {
                println("Выход...")
                break
            }

            try {
                val choice = input.toInt()
                val nextState = currentNode.getNextState(choice)

                if (nextState != null) {
                    // Обрабатываем события при переходе
                    handleEvents(currentState, nextState)
                    currentState = nextState
                } else {
                    println("Неверный выбор! Введите число от 1 до ${currentNode.getChoicesCount()}")
                }
            } catch (e: NumberFormatException) {
                println("Введите число!")
            }
        }
    }

    private fun handleEvents(fromState: `Контрольная работа`, toState: `Контрольная работа`) {
        println("\n--- Событие ---")

        when {
            fromState == `Контрольная работа`.START && toState == `Контрольная работа`.TALKING -> {
                println("Событие: Разговор начат")
            }

            fromState == `Контрольная работа`.TALKING && toState == `Контрольная работа`.ACCEPTED -> {
                println("Событие: Задание принято")
                // Сразу имитируем выполнение задания
                println("Событие: DUMMY_KILLED - манекен повержен")
            }

            fromState == `Контрольная работа`.TALKING && toState == `Контрольная работа`.DECLINE -> {
                println("Событие: Задание отклонено")
            }

            (fromState == `Контрольная работа`.ACCEPTED && toState == `Контрольная работа`.COMPLETED) ||
                    (fromState == `Контрольная работа`.DECLINE && toState == `Контрольная работа`.COMPLETED) -> {
                println("Событие: COMPLETED - квест завершен")
            }

            fromState == `Контрольная работа`.COMPLETED && toState == `Контрольная работа`.START -> {
                println("Событие: Начало нового диалога")
            }
        }
        println()
    }

    fun getCurrentState(): `Контрольная работа` = currentState
}